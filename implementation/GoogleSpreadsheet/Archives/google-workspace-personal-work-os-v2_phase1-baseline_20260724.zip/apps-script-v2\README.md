# Google Workspace Personal Work OS v2 - Phase 1

このDirectoryは、Google Workspace個人業務OS v2のPhase 1「最小Sheets基盤」です。新しい空のGoogle Sheetsへ紐づけるApps Scriptとして使用します。

## Phase 1の範囲

Phase 1は、10個のSheet、`タスク一覧`Schema、入力規則、段階Setup、Task Repository、synthetic Mock Task、Quick Diagnostic、Test Harnessだけを実装します。

次は未実装です。

- Gmailの検索、取得、ラベル作成
- AI API、Gemini Adapter、外部通信
- Calendarの作成、更新、削除
- installable edit trigger、5分trigger、本番Trigger
- v1からv2へのMigration
- 要確認専用タブ、独立Manualモード
- Dashboard集計、Worker、Dead Letter、将来拡張

v1.xとは非互換です。v1.xコードや既存Sheetをコピー、変換、上書きしないでください。

## 作成されるSheet

利用者向け:

1. `ダッシュボード`
2. `タスク一覧`
3. `設定`
4. `処理履歴`
5. `エラー・再実行`
6. `使い方`

非表示管理:

1. `メール状態`
2. `システム設定`
3. `プロンプト版管理`
4. `同期状態`

`タスク一覧`は行1が内部列ID、行2が日本語見出し、行3以降がTaskです。管理列は右側にあり、非表示です。Taskは`task_id`または`origin_key`がある行だけです。

## 導入手順

1. 機密情報を含まない、新しい空のGoogle Spreadsheetを作成します。
2. `拡張機能 > Apps Script`を開きます。
3. このDirectoryの`.gs`ファイルを同名で作成し、内容を貼り付けます。
4. Apps ScriptのProject Settingsでmanifest表示を有効にし、`appsscript.json`を置き換えます。
5. Spreadsheetを再読込し、メニュー`業務OS v2`を表示します。
6. `初期セットアップ`を実行し、本人のSpreadsheet権限だけを承認します。
7. 結果が`PHASE_BOUNDARY`、`next_stage=S50_CREATE_GMAIL_LABELS`であることを確認します。これはPhase 1の正常な停止点です。Gmailラベルは作成されません。
8. `Phase 1 Mock Taskをupsert`を2回実行します。
9. `Quick Diagnostic`を実行します。
10. `Phase 1テストを実行`し、結果を保存します。

`setupSystem()`はS00～S40を順に実行し、未実装のS50へ到達するとデータを変更せず安全停止します。`continueSetup()`も同じ状態から再開します。S50/S60/S80を完了扱いにしません。

## Phase 1の個別stage検証

Test HarnessまたはApps Script editorから、次のPhase 1 support stageを個別に検証できます。

```javascript
WorkOsSetup.runStageForTest('S70_STORE_PROPERTIES');
WorkOsSetup.runStageForTest('S90_QUICK_DIAGNOSTIC');
WorkOsSetup.runStageForTest('S80_CREATE_EDIT_TRIGGER');
```

S80は`NOT_YET_IMPLEMENTED`と`created_trigger=false`を返し、Triggerを作成しません。

## 手動受入チェック

新しいテストSpreadsheetで確認します。

1. 既定Sheetが`ダッシュボード`へrenameされ、10 Sheetが仕様順になる。
2. 管理4 Sheetが非表示になる。
3. `タスク一覧`の行1が内部ID、行2が日本語見出しになる。
4. 最初のMock Taskが行3に入り、同じMockを2回実行しても1件だけになる。
5. 空行のCheckboxセルが空であり、Boolean値`FALSE`が入っていない。
6. `コメント`へ自由記述でき、Checkboxが表示されない。
7. `判断`、`対応状況`、`期限根拠`、`優先度`、`Calendar登録`に仕様どおりのDropdownがある。
8. `期限`と`推奨期限`、日時列の表示形式が仕様どおりである。
9. setupを再実行してもMock Task、利用者入力、列、Sheetが消失・重複しない。
10. 別の検証Spreadsheetに`Review Queue`またはv1 markerを置くと、setupが変更前に停止する。
11. 別の検証Spreadsheetに未知の非空Sheetを置くと、setupが変更前に停止する。
12. Quick Diagnostic前後でセル値、行列数、表示/非表示、Schemaが変化しない。
13. Quick Diagnosticの実測が60秒以内である。
14. Apps ScriptのTriggers画面にPhase 1が作成したTriggerがない。
15. OAuth許可にGmail、Calendar、External request、Drive、Mail sendが含まれない。

Google Workspace実環境で実行していない項目はPASSにせず、未実施として記録してください。

## `clasp`を使う場合

`.clasp.json.example`をローカルで`.clasp.json`へコピーし、実際のScript IDはそのローカルファイルだけへ設定します。実際のScript ID、Spreadsheet ID、Calendar ID、Gmail Message ID、内部URLをRepositoryへ保存しないでください。

例:

```text
clasp login
clasp push
```

このRepositoryではcommit、push、deployを自動実行しません。

## 情報管理

保存禁止:

- API key、password、token、credential
- 実際のGmail Message ID、Spreadsheet ID、Calendar ID
- メール本文、添付内容、個人情報、未公表情報
- Google Workspace内部URL

Test HarnessのTaskは完全な架空データです。認証情報をSheetセル、ソースコード、README、fixture、logへ保存しないでください。

## 既知の制約

- Phase 1の公開SetupはS50で安全停止するため、v2全体のSetupは未完了です。
- Google Workspace固有のData Validation、保護、権限、実行時間は実環境での手動受入が必要です。
- Code Versionは`2.0.0-phase1`、Schema Versionは`2.0`、Migration Versionは`0`として分離しています。
- 補助タブの詳細UIは仕様未確定のため、Phase 1に必要な最小Schemaだけです。

