/**
 * Minimal Phase 1 Task Repository.
 *
 * The repository uses row 1 internal IDs and treats a row as logical Task data
 * only when task_id OR origin_key is present.
 */
var WorkOsTaskRepository = (function () {
  var IMMUTABLE_ON_EXISTING_UPSERT = Object.freeze({
    task_id: true,
    origin_key: true,
    created_at: true,
    comment: true
  });

  function calculateRowsToAppend(currentMaxRows, requiredRow) {
    if (requiredRow <= currentMaxRows) {
      return 0;
    }
    return Math.ceil(
      (requiredRow - currentMaxRows) / WorkOsConfig.ROW_EXPANSION_UNIT
    ) * WorkOsConfig.ROW_EXPANSION_UNIT;
  }

  function ensureCapacityForRow(sheet, requiredRow) {
    var rowsToAppend = calculateRowsToAppend(sheet.getMaxRows(), requiredRow);
    if (rowsToAppend > 0) {
      sheet.insertRowsAfter(sheet.getMaxRows(), rowsToAppend);
    }
    return rowsToAppend;
  }

  function findLogicalEmptyRow(taskIdValues, originKeyValues, startRow) {
    var firstDataRow = startRow || WorkOsConfig.DATA_START_ROW;
    var length = Math.max(taskIdValues.length, originKeyValues.length);
    for (var index = 0; index < length; index += 1) {
      var taskId = taskIdValues[index] && taskIdValues[index][0];
      var originKey = originKeyValues[index] && originKeyValues[index][0];
      if (WorkOsUtilities.isBlank(taskId) && WorkOsUtilities.isBlank(originKey)) {
        return firstDataRow + index;
      }
    }
    return firstDataRow + length;
  }

  function createContext(sheet) {
    var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
    var ids = sheet.getRange(1, 1, 1, schema.length).getValues()[0];
    var columnMap = WorkOsSchemas.buildColumnMapFromIds(ids);
    var expected = WorkOsSchemas.getInternalIds(WorkOsConfig.SHEETS.TASKS);
    if (JSON.stringify(ids) !== JSON.stringify(expected)) {
      throw new WorkOsAppError(
        'E_SCHEMA_MISSING_COLUMN',
        'TASK_REPOSITORY',
        false,
        'タスク一覧の内部列IDが仕様と一致しません。'
      );
    }
    var rowCount = Math.max(0, sheet.getMaxRows() - WorkOsConfig.DATA_START_ROW + 1);
    var values = rowCount
      ? sheet.getRange(WorkOsConfig.DATA_START_ROW, 1, rowCount, schema.length).getValues()
      : [];
    return buildContextFromValues(sheet, columnMap, values);
  }

  function buildContextFromValues(sheet, columnMap, values) {
    var byTaskId = {};
    var byOriginKey = {};
    var duplicateTaskIds = [];
    var duplicateOriginKeys = [];
    var logicalRows = [];
    var taskIdValues = [];
    var originKeyValues = [];
    var taskIdIndex = columnMap.task_id;
    var originKeyIndex = columnMap.origin_key;

    values.forEach(function (row, index) {
      var physicalRow = WorkOsConfig.DATA_START_ROW + index;
      var taskId = String(row[taskIdIndex] || '').trim();
      var originKey = String(row[originKeyIndex] || '').trim();
      taskIdValues.push([taskId]);
      originKeyValues.push([originKey]);
      if (!taskId && !originKey) {
        return;
      }
      logicalRows.push(physicalRow);
      if (taskId) {
        if (byTaskId[taskId]) {
          duplicateTaskIds.push(taskId);
        } else {
          byTaskId[taskId] = physicalRow;
        }
      }
      if (originKey) {
        if (byOriginKey[originKey]) {
          duplicateOriginKeys.push(originKey);
        } else {
          byOriginKey[originKey] = physicalRow;
        }
      }
    });

    return {
      sheet: sheet,
      columnMap: columnMap,
      values: values,
      taskIdValues: taskIdValues,
      originKeyValues: originKeyValues,
      byTaskId: byTaskId,
      byOriginKey: byOriginKey,
      duplicateTaskIds: duplicateTaskIds,
      duplicateOriginKeys: duplicateOriginKeys,
      logicalRows: logicalRows
    };
  }

  function valueForCell(columnDefinition, value) {
    if (value == null || value === '') {
      return '';
    }
    if (columnDefinition.enumName) {
      if (Object.prototype.hasOwnProperty.call(WorkOsEnums[columnDefinition.enumName], String(value))) {
        return WorkOsSchemas.toSheetEnum(columnDefinition.enumName, String(value));
      }
      WorkOsSchemas.toInternalEnum(columnDefinition.enumName, String(value));
      return String(value);
    }
    if (columnDefinition.type === 'Date') {
      if (value instanceof Date) {
        return value;
      }
      var dateText = String(value);
      var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateText);
      if (match) {
        return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
      }
      return new Date(value);
    }
    if (columnDefinition.type === 'DateTime') {
      return value instanceof Date ? value : new Date(value);
    }
    if (columnDefinition.type === 'Integer') {
      return Number(value);
    }
    if (columnDefinition.type === 'Number') {
      return Number(value);
    }
    if (columnDefinition.type === 'JsonArray') {
      return WorkOsUtilities.serializeJson(value, 'array');
    }
    if (columnDefinition.type === 'JsonObject') {
      return WorkOsUtilities.serializeJson(value, 'object');
    }
    return value;
  }

  function valueFromCell(columnDefinition, value) {
    if (value == null || value === '') {
      return '';
    }
    if (columnDefinition.enumName) {
      return WorkOsSchemas.toInternalEnum(columnDefinition.enumName, value);
    }
    if (columnDefinition.type === 'JsonArray') {
      return WorkOsUtilities.parseJson(value, 'array');
    }
    if (columnDefinition.type === 'JsonObject') {
      return WorkOsUtilities.parseJson(value, 'object');
    }
    if (columnDefinition.type === 'Integer' || columnDefinition.type === 'Number') {
      return Number(value);
    }
    if (columnDefinition.type === 'Boolean') {
      return Boolean(value);
    }
    return value;
  }

  function defaultTask(task, nowValue) {
    var result = {
      needs_review: false,
      decision: 'NONE',
      status: 'OPEN',
      completed: false,
      excluded: false,
      suggested_due_date: '',
      deadline_basis: 'NONE',
      priority: 'MEDIUM',
      waiting_for_reply: false,
      calendar_sync_mode: 'AUTO',
      comment: '',
      review_state: 'NONE',
      review_type: '',
      source_action_index: 0,
      ai_provider: 'MOCK',
      ai_prompt_version: 'phase1-mock',
      calendar_category: 'NONE',
      calendar_importance: 'LOW',
      calendar_sync_status: 'NOT_REQUIRED',
      schedule_state: 'NONE',
      manual_fields: [],
      row_version: 1,
      pending_action_type: '',
      pending_changes_json: {},
      created_at: nowValue,
      updated_at: nowValue
    };
    Object.keys(task || {}).forEach(function (key) {
      result[key] = task[key];
    });
    return result;
  }

  function makeRow(task) {
    var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
    return schema.map(function (item) {
      return Object.prototype.hasOwnProperty.call(task, item.id)
        ? valueForCell(item, task[item.id])
        : '';
    });
  }

  function rowForPhysicalRow(context, physicalRow) {
    var index = physicalRow - WorkOsConfig.DATA_START_ROW;
    if (index < 0 || index >= context.values.length) {
      throw new WorkOsAppError(
        'E_TASK_ROW_OUT_OF_RANGE',
        'TASK_REPOSITORY',
        false,
        'Task行が読取範囲外です。'
      );
    }
    return context.values[index].slice();
  }

  function cellsEqual(left, right) {
    if (left instanceof Date && right instanceof Date) {
      return left.getTime() === right.getTime();
    }
    return JSON.stringify(left) === JSON.stringify(right);
  }

  function upsertTask(task, context) {
    var target = task || {};
    var validation = WorkOsSchemas.validateTaskForWrite(target, true);
    if (!validation.ok) {
      throw new WorkOsAppError(
        'E_TASK_VALIDATION',
        'TASK_REPOSITORY',
        false,
        'Task入力が仕様を満たしません: ' + validation.errors.join(', ')
      );
    }
    var repositoryContext = context || createContext(
      SpreadsheetApp.getActiveSpreadsheet().getSheetByName(WorkOsConfig.SHEETS.TASKS)
    );
    if (repositoryContext.duplicateOriginKeys.length || repositoryContext.duplicateTaskIds.length) {
      throw new WorkOsAppError(
        'E_TASK_DUPLICATE_KEY',
        'TASK_REPOSITORY',
        false,
        '既存Taskに主キー重複があるため書込みを停止しました。'
      );
    }

    var existingRow = repositoryContext.byOriginKey[String(target.origin_key)];
    if (existingRow) {
      return updateExistingTask(target, repositoryContext, existingRow);
    }
    return insertTask(target, repositoryContext);
  }

  function updateExistingTask(task, context, physicalRow) {
    var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
    var existing = rowForPhysicalRow(context, physicalRow);
    var currentTaskId = String(existing[context.columnMap.task_id] || '');
    if (!currentTaskId) {
      throw new WorkOsAppError(
        'E_TASK_CONFLICT',
        'TASK_REPOSITORY',
        false,
        '既存origin_key行にtask_idがないため自動更新を停止しました。'
      );
    }
    if (task.task_id && String(task.task_id) !== currentTaskId) {
      throw new WorkOsAppError(
        'E_TASK_CONFLICT',
        'TASK_REPOSITORY',
        false,
        '同じorigin_keyに異なるtask_idが指定されました。'
      );
    }
    var updated = existing.slice();
    var changedFields = [];
    Object.keys(task).forEach(function (id) {
      if (IMMUTABLE_ON_EXISTING_UPSERT[id] || !Object.prototype.hasOwnProperty.call(context.columnMap, id)) {
        return;
      }
      var columnIndex = context.columnMap[id];
      var candidate = valueForCell(schema[columnIndex], task[id]);
      if (!cellsEqual(existing[columnIndex], candidate)) {
        updated[columnIndex] = candidate;
        changedFields.push(id);
      }
    });
    if (!changedFields.length) {
      return {
        operation: 'NOOP',
        row: physicalRow,
        task_id: currentTaskId,
        origin_key: String(task.origin_key),
        changed_fields: []
      };
    }
    var rowVersionIndex = context.columnMap.row_version;
    var updatedAtIndex = context.columnMap.updated_at;
    updated[rowVersionIndex] = Number(existing[rowVersionIndex] || 0) + 1;
    updated[updatedAtIndex] = WorkOsUtilities.now();
    context.sheet.getRange(physicalRow, 1, 1, schema.length).setValues([updated]);
    context.values[physicalRow - WorkOsConfig.DATA_START_ROW] = updated;
    changedFields.push('row_version', 'updated_at');
    return {
      operation: 'UPDATE',
      row: physicalRow,
      task_id: currentTaskId,
      origin_key: String(task.origin_key),
      changed_fields: changedFields
    };
  }

  function insertTask(task, context) {
    var nowValue = WorkOsUtilities.now();
    var prepared = defaultTask(task, nowValue);
    prepared.task_id = prepared.task_id || WorkOsUtilities.makeId('tsk_');
    prepared.origin_key = String(task.origin_key);
    var validation = WorkOsSchemas.validateTaskForWrite(prepared, true);
    if (!validation.ok) {
      throw new WorkOsAppError(
        'E_TASK_VALIDATION',
        'TASK_REPOSITORY',
        false,
        'Task入力が仕様を満たしません: ' + validation.errors.join(', ')
      );
    }
    var physicalRow = findLogicalEmptyRow(
      context.taskIdValues,
      context.originKeyValues,
      WorkOsConfig.DATA_START_ROW
    );
    var rowsAdded = ensureCapacityForRow(context.sheet, physicalRow);
    while (context.values.length < physicalRow - WorkOsConfig.DATA_START_ROW + 1) {
      context.values.push(new Array(WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS).length).fill(''));
      context.taskIdValues.push(['']);
      context.originKeyValues.push(['']);
    }
    var output = makeRow(prepared);
    context.sheet.getRange(physicalRow, 1, 1, output.length).setValues([output]);
    var valueIndex = physicalRow - WorkOsConfig.DATA_START_ROW;
    context.values[valueIndex] = output;
    context.taskIdValues[valueIndex] = [prepared.task_id];
    context.originKeyValues[valueIndex] = [prepared.origin_key];
    context.byTaskId[prepared.task_id] = physicalRow;
    context.byOriginKey[prepared.origin_key] = physicalRow;
    context.logicalRows.push(physicalRow);
    return {
      operation: 'INSERT',
      row: physicalRow,
      task_id: prepared.task_id,
      origin_key: prepared.origin_key,
      rows_added: rowsAdded,
      changed_fields: Object.keys(prepared)
    };
  }

  function readTaskAtRow(context, physicalRow) {
    var row = rowForPhysicalRow(context, physicalRow);
    var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
    var task = {};
    schema.forEach(function (item, index) {
      try {
        task[item.id] = valueFromCell(item, row[index]);
      } catch (error) {
        throw new WorkOsAppError(
          'E_INVALID_JSON',
          'TASK_REPOSITORY',
          false,
          'TaskのJSON列が不正です。'
        );
      }
    });
    return task;
  }

  function findByTaskId(context, taskId) {
    var row = context.byTaskId[String(taskId || '')];
    return row ? readTaskAtRow(context, row) : null;
  }

  function findByOriginKey(context, originKey) {
    var row = context.byOriginKey[String(originKey || '')];
    return row ? readTaskAtRow(context, row) : null;
  }

  function upsertPhase1MockTask() {
    var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
    if (!sheet) {
      throw new WorkOsAppError(
        'E_SCHEMA_MISSING_SHEET',
        'TASK_REPOSITORY',
        false,
        '先にPhase 1セットアップを実行してください。'
      );
    }
    var context = createContext(sheet);
    return upsertTask({
      origin_key: WorkOsUtilities.makeOriginKey('synthetic-message-phase1', 0),
      task_title: '架空資料の提出準備',
      status: 'OPEN',
      priority: 'MEDIUM',
      needs_review: false,
      completed: false,
      excluded: false,
      waiting_for_reply: false,
      source_action_index: 0,
      ai_provider: 'MOCK',
      ai_prompt_version: 'phase1-mock'
    }, context);
  }

  return Object.freeze({
    calculateRowsToAppend: calculateRowsToAppend,
    ensureCapacityForRow: ensureCapacityForRow,
    findLogicalEmptyRow: findLogicalEmptyRow,
    createContext: createContext,
    buildContextFromValues: buildContextFromValues,
    upsertTask: upsertTask,
    readTaskAtRow: readTaskAtRow,
    findByTaskId: findByTaskId,
    findByOriginKey: findByOriginKey,
    upsertPhase1MockTask: upsertPhase1MockTask
  });
}());
