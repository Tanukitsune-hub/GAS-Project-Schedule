/**
 * Phase 1 Quick Diagnostic. All checks are read-only.
 */
var WorkOsDiagnostics = (function () {
  function check(id, status, safeMessage, details) {
    return {
      id: id,
      status: status,
      safe_message: safeMessage || '',
      details: details || {}
    };
  }

  function criteriaEquals(rule, expected) {
    return rule && rule.getCriteriaType() === expected;
  }

  function validateTaskSheet(sheet, checks) {
    var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
    var ids = sheet.getRange(1, 1, 1, schema.length).getValues()[0];
    var headers = sheet.getRange(2, 1, 1, schema.length).getValues()[0];
    var comparison = WorkOsSchemas.compareHeaders(WorkOsConfig.SHEETS.TASKS, ids, headers);
    checks.push(check(
      'TASK_SCHEMA_IDS',
      comparison.idsMatch ? 'PASS' : 'FAIL',
      comparison.idsMatch ? '' : 'タスク一覧の内部列IDが一致しません。'
    ));
    checks.push(check(
      'TASK_SCHEMA_HEADERS',
      comparison.headersMatch ? 'PASS' : 'FAIL',
      comparison.headersMatch ? '' : 'タスク一覧の見出しが一致しません。'
    ));

    var context;
    try {
      context = WorkOsTaskRepository.createContext(sheet);
      checks.push(check('TASK_COLUMN_MAP', 'PASS', ''));
    } catch (error) {
      checks.push(check('TASK_COLUMN_MAP', 'FAIL', 'Column Mapを構築できません。'));
      return;
    }

    var validations = sheet.getRange(3, 1, 1, schema.length).getDataValidations()[0];
    var checkboxIds = ['needs_review', 'completed', 'excluded', 'waiting_for_reply'];
    var validationFailures = [];
    schema.forEach(function (item, index) {
      var rule = validations[index];
      if (checkboxIds.indexOf(item.id) !== -1) {
        if (!criteriaEquals(rule, SpreadsheetApp.DataValidationCriteria.CHECKBOX)) {
          validationFailures.push(item.id + ': checkbox missing');
        }
      } else if (criteriaEquals(rule, SpreadsheetApp.DataValidationCriteria.CHECKBOX)) {
        validationFailures.push(item.id + ': unexpected checkbox');
      }
      if (item.validation === 'ENUM' &&
          !criteriaEquals(rule, SpreadsheetApp.DataValidationCriteria.VALUE_IN_LIST)) {
        validationFailures.push(item.id + ': enum validation missing');
      }
    });
    checks.push(check(
      'TASK_VALIDATION_TYPES',
      validationFailures.length ? 'FAIL' : 'PASS',
      validationFailures.length ? '入力規則の型が一致しません。' : '',
      { failures: validationFailures }
    ));

    var formats = sheet.getRange(3, 1, 1, schema.length).getNumberFormats()[0];
    var formatFailures = [];
    schema.forEach(function (item, index) {
      if (item.type === 'Date' && formats[index] !== WorkOsConfig.DATE_FORMAT) {
        formatFailures.push(item.id);
      }
      if (item.type === 'DateTime' && formats[index] !== WorkOsConfig.DATETIME_FORMAT) {
        formatFailures.push(item.id);
      }
    });
    checks.push(check(
      'TASK_DATE_FORMATS',
      formatFailures.length ? 'FAIL' : 'PASS',
      formatFailures.length ? '日付表示形式が一致しません。' : '',
      { failures: formatFailures }
    ));

    var booleanIndexes = checkboxIds.map(function (id) { return context.columnMap[id]; });
    var blankBooleanRows = [];
    context.values.forEach(function (row, index) {
      var taskId = row[context.columnMap.task_id];
      var originKey = row[context.columnMap.origin_key];
      if (!WorkOsUtilities.isBlank(taskId) || !WorkOsUtilities.isBlank(originKey)) {
        return;
      }
      var hasBooleanValue = booleanIndexes.some(function (columnIndex) {
        return row[columnIndex] === true || row[columnIndex] === false;
      });
      if (hasBooleanValue) {
        blankBooleanRows.push(WorkOsConfig.DATA_START_ROW + index);
      }
    });
    checks.push(check(
      'BLANK_ROW_BOOLEAN_VALUES',
      blankBooleanRows.length ? 'FAIL' : 'PASS',
      blankBooleanRows.length ? '論理空行にBoolean値があります。' : '',
      { rows: blankBooleanRows.slice(0, 20) }
    ));

    checks.push(check(
      'TASK_PRIMARY_KEY_DUPLICATES',
      context.duplicateTaskIds.length || context.duplicateOriginKeys.length ? 'FAIL' : 'PASS',
      context.duplicateTaskIds.length || context.duplicateOriginKeys.length
        ? 'Task主キーに重複があります。'
        : '',
      {
        task_id_duplicates: context.duplicateTaskIds,
        origin_key_duplicates: context.duplicateOriginKeys
      }
    ));
    var incompleteKeyRows = context.logicalRows.filter(function (physicalRow) {
      var row = context.values[physicalRow - WorkOsConfig.DATA_START_ROW];
      return WorkOsUtilities.isBlank(row[context.columnMap.task_id]) ||
        WorkOsUtilities.isBlank(row[context.columnMap.origin_key]);
    });
    checks.push(check(
      'TASK_PRIMARY_KEY_COMPLETENESS',
      incompleteKeyRows.length ? 'FAIL' : 'PASS',
      incompleteKeyRows.length ? 'Task行の必須主キーが不足しています。' : '',
      { rows: incompleteKeyRows.slice(0, 20) }
    ));

    checks.push(check(
      'TASK_LOGICAL_ROWS',
      'PASS',
      '',
      {
        task_count: context.logicalRows.length,
        next_logical_empty_row: WorkOsTaskRepository.findLogicalEmptyRow(
          context.taskIdValues,
          context.originKeyValues,
          WorkOsConfig.DATA_START_ROW
        )
      }
    ));
  }

  function validateSheetSchema(sheet, sheetName, checks) {
    var schema = WorkOsSchemas.getSheetSchema(sheetName);
    var ids = sheet.getRange(1, 1, 1, schema.length).getValues()[0];
    var headers = sheet.getRange(2, 1, 1, schema.length).getValues()[0];
    var comparison = WorkOsSchemas.compareHeaders(sheetName, ids, headers);
    checks.push(check(
      'SCHEMA_' + WorkOsUtilities.sha256Hex(sheetName).slice(0, 8),
      comparison.idsMatch && comparison.headersMatch ? 'PASS' : 'FAIL',
      comparison.idsMatch && comparison.headersMatch
        ? ''
        : sheetName + 'のSchemaが一致しません。',
      { sheet_name: sheetName }
    ));
  }

  function runQuickDiagnostic(spreadsheet) {
    var startedAt = Date.now();
    var target = spreadsheet || SpreadsheetApp.getActiveSpreadsheet();
    var checks = [];
    if (!target) {
      return {
        status: 'FAIL',
        code_version: WorkOsConfig.CODE_VERSION,
        schema_version: WorkOsConfig.SCHEMA_VERSION,
        duration_ms: Date.now() - startedAt,
        checks: [check('BOUND_SPREADSHEET', 'FAIL', 'Bound Spreadsheetがありません。')]
      };
    }

    WorkOsSheetOrder.forEach(function (sheetName) {
      var sheet = target.getSheetByName(sheetName);
      if (!sheet) {
        checks.push(check('SHEET_' + WorkOsUtilities.sha256Hex(sheetName).slice(0, 8), 'FAIL', '必須Sheetがありません。', {
          sheet_name: sheetName
        }));
        return;
      }
      var minimumRows = WorkOsSheetBuilder.initialRowsForSheet(sheetName);
      var rowCount = sheet.getMaxRows();
      var rowCountValid = rowCount >= minimumRows &&
        (rowCount - minimumRows) % WorkOsConfig.ROW_EXPANSION_UNIT === 0;
      checks.push(check(
        'ROWS_' + WorkOsUtilities.sha256Hex(sheetName).slice(0, 8),
        rowCountValid ? 'PASS' : 'FAIL',
        rowCountValid ? '' : '行数が初期値または100行単位の拡張と一致しません。',
        {
          sheet_name: sheetName,
          rows: rowCount,
          minimum_rows: minimumRows,
          expansion_unit: WorkOsConfig.ROW_EXPANSION_UNIT
        }
      ));
      if (sheetName === WorkOsConfig.SHEETS.TASKS) {
        validateTaskSheet(sheet, checks);
      } else {
        validateSheetSchema(sheet, sheetName, checks);
      }
      var expectedHidden = WorkOsHiddenSheets.indexOf(sheetName) !== -1;
      checks.push(check(
        'VISIBILITY_' + WorkOsUtilities.sha256Hex(sheetName).slice(0, 8),
        sheet.isSheetHidden() === expectedHidden ? 'PASS' : 'FAIL',
        sheet.isSheetHidden() === expectedHidden ? '' : 'Sheet表示状態が仕様と一致しません。',
        { sheet_name: sheetName, expected_hidden: expectedHidden }
      ));
    });

    var props = PropertiesService.getScriptProperties();
    var completedRaw = props.getProperty(WorkOsConfig.PROPERTIES.SETUP_COMPLETED_STAGES);
    var codeProperty = props.getProperty(WorkOsConfig.PROPERTIES.CODE_VERSION);
    var schemaProperty = props.getProperty(WorkOsConfig.PROPERTIES.SCHEMA_VERSION);
    checks.push(check(
      'SETUP_PROPERTIES',
      completedRaw ? 'PASS' : 'WARN',
      completedRaw ? '' : 'Setup段階のPropertiesがまだありません。',
      { completed_stages_recorded: Boolean(completedRaw) }
    ));
    checks.push(check(
      'VERSION_PROPERTIES',
      codeProperty === WorkOsConfig.CODE_VERSION &&
        schemaProperty === WorkOsConfig.SCHEMA_VERSION
        ? 'PASS'
        : 'WARN',
      codeProperty === WorkOsConfig.CODE_VERSION &&
        schemaProperty === WorkOsConfig.SCHEMA_VERSION
        ? ''
        : 'S70未実行のためversion Propertiesは未確定です。',
      {
        code_version_property_matches: codeProperty === WorkOsConfig.CODE_VERSION,
        schema_version_property_matches: schemaProperty === WorkOsConfig.SCHEMA_VERSION
      }
    ));
    checks.push(check(
      'EDIT_TRIGGER',
      'NOT_YET_IMPLEMENTED',
      'Phase 1では本番Triggerを作成しません。'
    ));
    checks.push(check(
      'GMAIL_CALENDAR_AI',
      'NOT_YET_IMPLEMENTED',
      'Gmail、Calendar、外部AIはPhase 1の対象外です。'
    ));

    var duration = Date.now() - startedAt;
    checks.push(check(
      'QUICK_DIAGNOSTIC_DURATION',
      duration <= WorkOsConfig.QUICK_DIAGNOSTIC_TARGET_MS ? 'PASS' : 'FAIL',
      duration <= WorkOsConfig.QUICK_DIAGNOSTIC_TARGET_MS ? '' : 'Quick Diagnosticが目標時間を超過しました。',
      { duration_ms: duration, target_ms: WorkOsConfig.QUICK_DIAGNOSTIC_TARGET_MS }
    ));
    var hasFailure = checks.some(function (item) { return item.status === 'FAIL'; });
    var hasWarning = checks.some(function (item) {
      return item.status === 'WARN' || item.status === 'NOT_YET_IMPLEMENTED';
    });
    var completedStages = [];
    if (completedRaw) {
      try {
        var parsedStages = JSON.parse(completedRaw);
        completedStages = Array.isArray(parsedStages) ? parsedStages : [];
      } catch (error) {
        checks.push(check(
          'SETUP_PROPERTIES_PARSE',
          'FAIL',
          'Setup段階のPropertiesを解析できません。'
        ));
        hasFailure = true;
      }
    }

    return {
      status: hasFailure ? 'FAIL' : (hasWarning ? 'WARN' : 'PASS'),
      code_version: WorkOsConfig.CODE_VERSION,
      schema_version: WorkOsConfig.SCHEMA_VERSION,
      migration_version: WorkOsConfig.MIGRATION_VERSION,
      setup_completed_stages: completedStages,
      duration_ms: Date.now() - startedAt,
      checks: checks
    };
  }

  return Object.freeze({
    runQuickDiagnostic: runQuickDiagnostic
  });
}());

function runQuickDiagnostic() {
  return WorkOsDiagnostics.runQuickDiagnostic(SpreadsheetApp.getActiveSpreadsheet());
}
