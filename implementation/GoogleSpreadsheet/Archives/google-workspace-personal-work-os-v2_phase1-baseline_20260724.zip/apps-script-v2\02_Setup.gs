/**
 * New-environment-only, staged Phase 1 setup.
 */
var WorkOsSetup = (function () {
  function getBoundSpreadsheet() {
    var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    if (!spreadsheet) {
      throw new WorkOsAppError(
        'E_SETUP_NOT_BOUND',
        'S00_VALIDATE_ENV',
        false,
        'Bound Spreadsheetから実行してください。'
      );
    }
    return spreadsheet;
  }

  function snapshotEnvironment(spreadsheet) {
    return spreadsheet.getSheets().map(function (sheet) {
      var values = sheet.getDataRange().getDisplayValues();
      var firstRow = values.length ? values[0].slice() : [];
      var secondRow = values.length > 1 ? values[1].slice() : [];
      var isEmpty = values.every(function (row) {
        return row.every(function (value) {
          return WorkOsUtilities.isBlank(value);
        });
      });
      return {
        name: sheet.getName(),
        isEmpty: isEmpty,
        firstRow: firstRow,
        secondRow: secondRow
      };
    });
  }

  function hasV1Marker(descriptor) {
    if (WorkOsConfig.V1_SHEET_NAMES.indexOf(descriptor.name) !== -1) {
      return true;
    }
    var text = descriptor.firstRow.concat(descriptor.secondRow).join(' ');
    return /Review Queue/i.test(text) ||
      /\bv1(?:\.|\b)/i.test(text) ||
      /schema[_ ]?version[^0-9]*1\./i.test(text);
  }

  function classifyEnvironmentDescriptors(descriptors) {
    var items = descriptors || [];
    if (!items.length) {
      return { allowed: false, code: 'E_SETUP_NO_SHEETS', kind: 'INVALID' };
    }
    if (items.some(hasV1Marker)) {
      return { allowed: false, code: 'E_V1_DETECTED', kind: 'V1' };
    }

    var knownNames = {};
    WorkOsSheetOrder.forEach(function (name) { knownNames[name] = true; });
    var unknown = items.filter(function (item) { return !knownNames[item.name]; });
    var known = items.filter(function (item) { return knownNames[item.name]; });

    if (unknown.length === 1 && known.length === 0 && unknown[0].isEmpty) {
      return { allowed: true, code: 'OK_NEW_EMPTY', kind: 'NEW_EMPTY' };
    }
    if (unknown.length) {
      return {
        allowed: false,
        code: unknown.some(function (item) { return !item.isEmpty; })
          ? 'E_SETUP_NOT_EMPTY'
          : 'E_SETUP_UNKNOWN_SHEET',
        kind: 'UNKNOWN'
      };
    }

    for (var index = 0; index < known.length; index += 1) {
      var descriptor = known[index];
      var schema = WorkOsSchemas.getSheetSchema(descriptor.name);
      var expectedIds = schema.map(function (item) { return item.id; });
      var expectedHeaders = schema.map(function (item) { return item.header; });
      var ids = descriptor.firstRow.slice(0, expectedIds.length);
      var headers = descriptor.secondRow.slice(0, expectedHeaders.length);
      var idsBlank = ids.every(WorkOsUtilities.isBlank);
      var headersBlank = headers.every(WorkOsUtilities.isBlank);
      var idsExact = JSON.stringify(ids) === JSON.stringify(expectedIds);
      var headersSafe = headers.every(function (value, headerIndex) {
        return WorkOsUtilities.isBlank(value) || String(value) === expectedHeaders[headerIndex];
      });
      if (!descriptor.isEmpty && !(idsExact && headersSafe)) {
        return { allowed: false, code: 'E_SCHEMA_CONFLICT', kind: 'CONFLICT' };
      }
      if (descriptor.isEmpty && !(idsBlank && headersBlank) && !(idsExact && headersSafe)) {
        return { allowed: false, code: 'E_SCHEMA_CONFLICT', kind: 'CONFLICT' };
      }
    }
    return { allowed: true, code: 'OK_V2_RESUMABLE', kind: 'V2_RESUMABLE' };
  }

  function assertEditable(spreadsheet) {
    var email = '';
    try {
      email = Session.getEffectiveUser().getEmail();
      if (!email) {
        return { checked: false, reason: 'effective user email unavailable' };
      }
      var owner = spreadsheet.getOwner();
      var editors = spreadsheet.getEditors();
      var allowed = owner && owner.getEmail() === email;
      if (!allowed) {
        allowed = editors.some(function (editor) { return editor.getEmail() === email; });
      }
      if (!allowed) {
        throw new WorkOsAppError(
          'E_SETUP_NO_EDIT_ACCESS',
          'S00_VALIDATE_ENV',
          false,
          'Spreadsheetの編集権限を確認できません。'
        );
      }
      return { checked: true, reason: '' };
    } catch (error) {
      if (error instanceof WorkOsAppError) {
        throw error;
      }
      // Domain or group permissions may hide the editor list. Actual setup
      // writes remain guarded by per-stage exceptions.
      return { checked: false, reason: 'editor list unavailable' };
    }
  }

  function validateEnvironment(spreadsheet) {
    var classification = classifyEnvironmentDescriptors(snapshotEnvironment(spreadsheet));
    if (!classification.allowed) {
      var message = classification.code === 'E_V1_DETECTED'
        ? 'v1らしい環境を検出しました。自動変換せず停止します。'
        : '新規空Sheetまたは再開可能なv2環境ではないため停止します。';
      throw new WorkOsAppError(
        classification.code,
        'S00_VALIDATE_ENV',
        false,
        message
      );
    }
    var editCheck = assertEditable(spreadsheet);
    return {
      environment: classification.kind,
      edit_access_check: editCheck.checked ? 'PASS' : 'UNVERIFIED'
    };
  }

  function properties() {
    return PropertiesService.getScriptProperties();
  }

  function getCompletedStages() {
    var raw = properties().getProperty(WorkOsConfig.PROPERTIES.SETUP_COMPLETED_STAGES);
    if (!raw) {
      return [];
    }
    try {
      var parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      throw new WorkOsAppError(
        'E_SETUP_STATE_INVALID',
        'SETUP',
        false,
        'Setup状態が不正です。自動修復は行いません。'
      );
    }
  }

  function getCompletedStagesSafely() {
    try {
      return getCompletedStages();
    } catch (error) {
      return [];
    }
  }

  function recordCompletedStage(stage) {
    var completed = getCompletedStages();
    if (completed.indexOf(stage) === -1) {
      completed.push(stage);
      properties().setProperty(
        WorkOsConfig.PROPERTIES.SETUP_COMPLETED_STAGES,
        JSON.stringify(completed)
      );
    }
  }

  function storeLastResult(result) {
    properties().setProperty(
      WorkOsConfig.PROPERTIES.SETUP_LAST_RESULT,
      JSON.stringify({
        status: result.status,
        code: result.code || '',
        next_stage: result.next_stage || '',
        recorded_at: new Date().toISOString()
      })
    );
  }

  function runImplementedStage(stage, spreadsheet) {
    if (stage === 'S00_VALIDATE_ENV') {
      return validateEnvironment(spreadsheet);
    }
    if (stage === 'S10_CREATE_SHEETS') {
      return WorkOsSheetBuilder.ensureSheets(spreadsheet);
    }
    if (stage === 'S20_CREATE_SCHEMAS') {
      return WorkOsSheetBuilder.applyAllSchemas(spreadsheet);
    }
    if (stage === 'S30_APPLY_SMALL_VALIDATIONS') {
      WorkOsSheetBuilder.applyValidationsAndFormats(spreadsheet);
      WorkOsSheetBuilder.applyVisibility(spreadsheet);
      return { applied: true };
    }
    if (stage === 'S40_SEED_SAFE_SETTINGS') {
      WorkOsSheetBuilder.seedSafeSettings(spreadsheet);
      return { seeded: true };
    }
    if (stage === 'S70_STORE_PROPERTIES') {
      var props = properties();
      if (!props.getProperty(WorkOsConfig.PROPERTIES.INSTANCE_ID)) {
        props.setProperty(WorkOsConfig.PROPERTIES.INSTANCE_ID, WorkOsUtilities.makeId('ins_'));
      }
      props.setProperties({
        WORK_OS_V2_CODE_VERSION: WorkOsConfig.CODE_VERSION,
        WORK_OS_V2_SCHEMA_VERSION: WorkOsConfig.SCHEMA_VERSION,
        WORK_OS_V2_MIGRATION_VERSION: WorkOsConfig.MIGRATION_VERSION
      }, false);
      return { stored: true };
    }
    if (stage === 'S90_QUICK_DIAGNOSTIC') {
      return WorkOsDiagnostics.runQuickDiagnostic(spreadsheet);
    }
    throw new WorkOsAppError(
      'SETUP_STAGE_NOT_IMPLEMENTED',
      stage,
      false,
      stage + 'はPhase 1では未実装です。外部副作用は実行していません。'
    );
  }

  function executeSetup() {
    var startedAt = Date.now();
    var budget = WorkOsUtilities.createSoftBudget(WorkOsConfig.SETUP_SOFT_LIMIT_MS, startedAt);
    var spreadsheet;
    try {
      spreadsheet = getBoundSpreadsheet();
      // Environment safety is revalidated on every invocation, even when S00
      // was completed previously. A stale property must never bypass safety.
      validateEnvironment(spreadsheet);
      var completed = getCompletedStages();
      if (completed.indexOf('S00_VALIDATE_ENV') === -1) {
        recordCompletedStage('S00_VALIDATE_ENV');
        completed = getCompletedStages();
      }
      var stageResults = [];
      for (var index = 0; index < WorkOsConfig.SETUP_STAGES.length; index += 1) {
        var stage = WorkOsConfig.SETUP_STAGES[index];
        if (completed.indexOf(stage) !== -1) {
          continue;
        }
        if (budget.isExhausted(5000)) {
          var budgetResult = {
            status: 'PAUSED',
            code: 'E_BUDGET_EXHAUSTED',
            next_stage: stage,
            completed_stages: getCompletedStages(),
            duration_ms: Date.now() - startedAt
          };
          storeLastResult(budgetResult);
          return budgetResult;
        }
        if (WorkOsConfig.PHASE1_IMPLEMENTED_STAGES.indexOf(stage) === -1) {
          var phaseBoundaryResult = {
            status: 'PHASE_BOUNDARY',
            code: 'SETUP_STAGE_NOT_IMPLEMENTED',
            next_stage: stage,
            completed_stages: getCompletedStages(),
            duration_ms: Date.now() - startedAt,
            safe_message: stage + 'は後続Phaseのため実行していません。'
          };
          storeLastResult(phaseBoundaryResult);
          return phaseBoundaryResult;
        }
        if (stage === 'S00_VALIDATE_ENV') {
          continue;
        }
        var stageStartedAt = Date.now();
        var output = runImplementedStage(stage, spreadsheet);
        recordCompletedStage(stage);
        stageResults.push({
          stage: stage,
          duration_ms: Date.now() - stageStartedAt,
          result: output ? 'COMPLETED' : 'COMPLETED'
        });
        completed = getCompletedStages();
      }
      var completeResult = {
        status: 'COMPLETE',
        code: '',
        completed_stages: getCompletedStages(),
        stage_results: stageResults,
        duration_ms: Date.now() - startedAt
      };
      storeLastResult(completeResult);
      return completeResult;
    } catch (error) {
      var safe = WorkOsUtilities.safeError(error, 'SETUP');
      return {
        status: 'FAILED',
        code: safe.code,
        stage: safe.stage,
        safe_message: safe.safe_message,
        completed_stages: getCompletedStagesSafely(),
        duration_ms: Date.now() - startedAt
      };
    }
  }

  function runStageForTest(stage) {
    if (!WorkOsConfig.TEST_MODE) {
      throw new WorkOsAppError(
        'E_TEST_MODE_DISABLED',
        stage,
        false,
        'Test modeが無効です。'
      );
    }
    if (stage === 'S80_CREATE_EDIT_TRIGGER') {
      return {
        status: 'NOT_YET_IMPLEMENTED',
        created_trigger: false,
        safe_message: 'Phase 1では本番Triggerを作成しません。'
      };
    }
    var spreadsheet = getBoundSpreadsheet();
    if (stage !== 'S00_VALIDATE_ENV') {
      validateEnvironment(spreadsheet);
    }
    var result = runImplementedStage(stage, spreadsheet);
    recordCompletedStage(stage);
    return result;
  }

  return Object.freeze({
    snapshotEnvironment: snapshotEnvironment,
    classifyEnvironmentDescriptors: classifyEnvironmentDescriptors,
    validateEnvironment: validateEnvironment,
    getCompletedStages: getCompletedStages,
    executeSetup: executeSetup,
    runStageForTest: runStageForTest
  });
}());

function setupSystem() {
  return WorkOsSetup.executeSetup();
}

function continueSetup() {
  return WorkOsSetup.executeSetup();
}
