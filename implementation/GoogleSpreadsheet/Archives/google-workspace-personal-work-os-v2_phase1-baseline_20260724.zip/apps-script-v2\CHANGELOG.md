# Changelog

## 2.0.0-phase1 - 2026-07-24

### Added

- New zero-based Apps Script v2 Phase 1 foundation.
- Ten-Sheet setup contract with internal IDs, Japanese headers, validation, formats, visibility, and small initial grids.
- Staged, resumable setup with safe v1 and unknown-environment detection.
- Internal-ID Column Map and logical-empty-row Task Repository.
- Typed, idempotent synthetic Task upsert with `created_at`, `updated_at`, and `row_version`.
- Read-only Phase 1 Quick Diagnostic.
- Apps Script acceptance harness and local Node.js tests.
- Minimal manifest, custom menu, `.clasp.json.example`, and installation guide.

### Validation

- JavaScript syntax check: 10/10 `.gs` files passed.
- Local Phase 1 tests: 15/15 passed.
- Static guardrails: no Task-append `getLastRow()`, blank-row `setValue(false)`, external Gmail/Calendar/AI runtime API, production trigger creation, or credential signature found.

### Known limitations

- Google Workspace manual acceptance is not executed in the local environment.
- Public setup intentionally stops at the unimplemented Phase 2 stage `S50_CREATE_GMAIL_LABELS`.
- No production trigger, Gmail, Calendar, external AI, or v1 migration is implemented.

