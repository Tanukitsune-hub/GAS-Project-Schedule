/**
 * Google Workspace Personal Work OS v2 - Phase 1 configuration.
 *
 * This file is intentionally free of Spreadsheet writes and external service calls.
 */
var WorkOsConfig = Object.freeze({
  SYSTEM_NAME: 'Google Workspace Personal Work OS v2',
  CODE_VERSION: '2.0.0-phase1',
  SCHEMA_VERSION: '2.0',
  MIGRATION_VERSION: '0',
  TIMEZONE: 'Asia/Tokyo',
  HEADER_ID_ROW: 1,
  HEADER_LABEL_ROW: 2,
  DATA_START_ROW: 3,
  TASK_INITIAL_ROWS: 100,
  SETTINGS_INITIAL_ROWS: 50,
  DEFAULT_INITIAL_ROWS: 100,
  ROW_EXPANSION_UNIT: 100,
  SETUP_SOFT_LIMIT_MS: 120000,
  QUICK_DIAGNOSTIC_TARGET_MS: 60000,
  AI_PROVIDER: 'MOCK',
  AUTOMATION_ENABLED: false,
  DEADLINE_CALENDAR_NAME: '自動期日管理',
  GMAIL_LABELS: Object.freeze([
    'AI/要対応',
    'AI/期限',
    'AI/返信待',
    'AI/要確認',
    '手動/取込',
    '手動/除外',
    'SYS/失敗'
  ]),
  SHEETS: Object.freeze({
    DASHBOARD: 'ダッシュボード',
    TASKS: 'タスク一覧',
    SETTINGS: '設定',
    RUN_HISTORY: '処理履歴',
    ERRORS: 'エラー・再実行',
    GUIDE: '使い方',
    MESSAGE_STATE: 'メール状態',
    SYSTEM_CONFIG: 'システム設定',
    PROMPT_VERSIONS: 'プロンプト版管理',
    SYNC_STATE: '同期状態'
  }),
  V1_SHEET_NAMES: Object.freeze([
    '要確認',
    'Review Queue',
    'review_queue',
    'system_config',
    'history',
    'task_master',
    'メール一覧'
  ]),
  PROPERTIES: Object.freeze({
    INSTANCE_ID: 'WORK_OS_V2_INSTANCE_ID',
    CODE_VERSION: 'WORK_OS_V2_CODE_VERSION',
    SCHEMA_VERSION: 'WORK_OS_V2_SCHEMA_VERSION',
    MIGRATION_VERSION: 'WORK_OS_V2_MIGRATION_VERSION',
    SETUP_COMPLETED_STAGES: 'WORK_OS_V2_SETUP_COMPLETED_STAGES',
    SETUP_LAST_RESULT: 'WORK_OS_V2_SETUP_LAST_RESULT'
  }),
  SETUP_STAGES: Object.freeze([
    'S00_VALIDATE_ENV',
    'S10_CREATE_SHEETS',
    'S20_CREATE_SCHEMAS',
    'S30_APPLY_SMALL_VALIDATIONS',
    'S40_SEED_SAFE_SETTINGS',
    'S50_CREATE_GMAIL_LABELS',
    'S60_CREATE_DEADLINE_CALENDAR',
    'S70_STORE_PROPERTIES',
    'S80_CREATE_EDIT_TRIGGER',
    'S90_QUICK_DIAGNOSTIC',
    'S99_COMPLETE'
  ]),
  PHASE1_IMPLEMENTED_STAGES: Object.freeze([
    'S00_VALIDATE_ENV',
    'S10_CREATE_SHEETS',
    'S20_CREATE_SCHEMAS',
    'S30_APPLY_SMALL_VALIDATIONS',
    'S40_SEED_SAFE_SETTINGS',
    'S70_STORE_PROPERTIES',
    'S90_QUICK_DIAGNOSTIC'
  ]),
  DATE_FORMAT: 'yyyy/mm/dd',
  DATETIME_FORMAT: 'yyyy/mm/dd hh:mm:ss',
  TEST_MODE: true
});

var WorkOsEnums = Object.freeze({
  TaskStatus: Object.freeze({
    REVIEW: '要確認',
    OPEN: '未対応',
    IN_PROGRESS: '対応中',
    WAITING: '返信待ち',
    DONE: '完了',
    EXCLUDED: '対象外',
    CANCELLED: '取消'
  }),
  Decision: Object.freeze({
    NONE: '未選択',
    ACCEPT: '受入',
    REJECT: '却下'
  }),
  Priority: Object.freeze({
    HIGH: '高',
    MEDIUM: '中',
    LOW: '低'
  }),
  DeadlineBasis: Object.freeze({
    EXPLICIT: '明示',
    RELATIVE: '相対',
    INFERRED: '推測',
    AMBIGUOUS: '曖昧',
    NONE: 'なし'
  }),
  CalendarSyncMode: Object.freeze({
    AUTO: '自動',
    FORCE: '登録',
    NONE: '対象外'
  }),
  ReviewState: Object.freeze({
    NONE: 'なし',
    OPEN: '未確認',
    APPLIED: '適用済',
    REJECTED: '却下済'
  }),
  CalendarImportance: Object.freeze({
    LOW: 'LOW',
    MEDIUM: 'MEDIUM',
    HIGH: 'HIGH'
  }),
  CalendarSyncStatus: Object.freeze({
    NOT_REQUIRED: 'NOT_REQUIRED',
    PENDING: 'PENDING',
    SYNCED: 'SYNCED',
    DELETE_PENDING: 'DELETE_PENDING',
    ERROR: 'ERROR'
  }),
  ScheduleState: Object.freeze({
    NONE: 'NONE',
    FUTURE: 'FUTURE',
    UPCOMING: 'UPCOMING',
    TODAY: 'TODAY',
    OVERDUE: 'OVERDUE'
  })
});

var WorkOsSheetOrder = Object.freeze([
  WorkOsConfig.SHEETS.DASHBOARD,
  WorkOsConfig.SHEETS.TASKS,
  WorkOsConfig.SHEETS.SETTINGS,
  WorkOsConfig.SHEETS.RUN_HISTORY,
  WorkOsConfig.SHEETS.ERRORS,
  WorkOsConfig.SHEETS.GUIDE,
  WorkOsConfig.SHEETS.MESSAGE_STATE,
  WorkOsConfig.SHEETS.SYSTEM_CONFIG,
  WorkOsConfig.SHEETS.PROMPT_VERSIONS,
  WorkOsConfig.SHEETS.SYNC_STATE
]);

var WorkOsHiddenSheets = Object.freeze([
  WorkOsConfig.SHEETS.MESSAGE_STATE,
  WorkOsConfig.SHEETS.SYSTEM_CONFIG,
  WorkOsConfig.SHEETS.PROMPT_VERSIONS,
  WorkOsConfig.SHEETS.SYNC_STATE
]);

