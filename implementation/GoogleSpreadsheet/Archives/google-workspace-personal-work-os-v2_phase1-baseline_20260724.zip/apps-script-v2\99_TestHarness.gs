/**
 * Phase 1 Apps Script acceptance harness.
 *
 * Run only in a new, non-confidential test Spreadsheet. It never connects to
 * Gmail, Calendar, AI, or any external service.
 */
var WorkOsTestHarness = (function () {
  function assertTrue(condition, message) {
    if (!condition) {
      throw new Error(message || 'assertion failed');
    }
  }

  function assertEqual(expected, actual, message) {
    if (JSON.stringify(expected) !== JSON.stringify(actual)) {
      throw new Error(
        (message || 'values differ') +
        ' expected=' + JSON.stringify(expected) +
        ' actual=' + JSON.stringify(actual)
      );
    }
  }

  function result(id, startedAt, error, skippedMessage) {
    return {
      id: id,
      status: skippedMessage ? 'SKIPPED' : (error ? 'FAIL' : 'PASS'),
      duration_ms: Date.now() - startedAt,
      safe_message: skippedMessage || (error ? WorkOsUtilities.redact(error.message) : '')
    };
  }

  function runTest(id, functionUnderTest) {
    var startedAt = Date.now();
    try {
      functionUnderTest();
      return result(id, startedAt, null, '');
    } catch (error) {
      return result(id, startedAt, error, '');
    }
  }

  function countLogicalTasks(context) {
    return context.logicalRows.length;
  }

  function phase1MockOriginKey() {
    return WorkOsUtilities.makeOriginKey('synthetic-message-phase1', 0);
  }

  function sheetFingerprint(spreadsheet) {
    return JSON.stringify(spreadsheet.getSheets().map(function (sheet) {
      var schema = WorkOsSheetOrder.indexOf(sheet.getName()) !== -1
        ? WorkOsSchemas.getSheetSchema(sheet.getName())
        : [];
      var headerWidth = Math.max(1, schema.length);
      var result = {
        name: sheet.getName(),
        max_rows: sheet.getMaxRows(),
        max_columns: sheet.getMaxColumns(),
        hidden: sheet.isSheetHidden(),
        headers: sheet.getRange(1, 1, 2, headerWidth).getValues()
      };
      if (sheet.getName() === WorkOsConfig.SHEETS.TASKS) {
        result.task_values = sheet.getRange(
          3,
          1,
          sheet.getMaxRows() - 2,
          schema.length
        ).getValues();
      }
      return result;
    }));
  }

  function phase1Tests() {
    var spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    var tests = [];

    tests.push(runTest('P1-A01_REQUIRED_SHEETS', function () {
      assertTrue(Boolean(spreadsheet), 'Bound Spreadsheet is required');
      assertEqual(
        WorkOsSheetOrder,
        spreadsheet.getSheets().map(function (sheet) { return sheet.getName(); }),
        'required Sheet order differs'
      );
    }));

    tests.push(runTest('P1-A02_TASK_HEADERS', function () {
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
      assertEqual(
        WorkOsSchemas.getInternalIds(WorkOsConfig.SHEETS.TASKS),
        sheet.getRange(1, 1, 1, schema.length).getValues()[0],
        'row 1 internal IDs differ'
      );
      assertEqual(
        WorkOsSchemas.getHeaders(WorkOsConfig.SHEETS.TASKS),
        sheet.getRange(2, 1, 1, schema.length).getValues()[0],
        'row 2 headers differ'
      );
    }));

    tests.push(runTest('P1-A03_MOCK_TASK_ROW', function () {
      var first = WorkOsTaskRepository.upsertPhase1MockTask();
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      var context = WorkOsTaskRepository.createContext(sheet);
      var task = WorkOsTaskRepository.findByOriginKey(
        context,
        phase1MockOriginKey()
      );
      assertTrue(Boolean(task), 'synthetic Task was not written');
      if (countLogicalTasks(context) === 1) {
        assertEqual(3, first.row, 'first Task must be written at row 3');
      }
    }));

    tests.push(runTest('P1-A04_BLANK_BOOLEAN', function () {
      var diagnostic = WorkOsDiagnostics.runQuickDiagnostic(spreadsheet);
      var target = diagnostic.checks.filter(function (item) {
        return item.id === 'BLANK_ROW_BOOLEAN_VALUES';
      })[0];
      assertEqual('PASS', target && target.status, 'blank row contains Boolean value');
    }));

    tests.push(runTest('P1-A05_COMMENT_NO_CHECKBOX', function () {
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      var map = WorkOsSchemas.buildColumnMapFromIds(
        WorkOsSchemas.getInternalIds(WorkOsConfig.SHEETS.TASKS)
      );
      var rule = sheet.getRange(3, map.comment + 1).getDataValidation();
      assertTrue(
        !rule || rule.getCriteriaType() !== SpreadsheetApp.DataValidationCriteria.CHECKBOX,
        'comment has checkbox validation'
      );
    }));

    tests.push(runTest('P1-A06_CHECKBOX_COLUMNS_ONLY', function () {
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      var schema = WorkOsSchemas.getSheetSchema(WorkOsConfig.SHEETS.TASKS);
      var rules = sheet.getRange(3, 1, 1, schema.length).getDataValidations()[0];
      var checkboxIds = [];
      rules.forEach(function (rule, index) {
        if (rule && rule.getCriteriaType() === SpreadsheetApp.DataValidationCriteria.CHECKBOX) {
          checkboxIds.push(schema[index].id);
        }
      });
      assertEqual(
        ['needs_review', 'completed', 'excluded', 'waiting_for_reply'],
        checkboxIds,
        'checkbox validation columns differ'
      );
    }));

    tests.push(runTest('P1-A07_IDEMPOTENT_UPSERT', function () {
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      var before = WorkOsTaskRepository.createContext(sheet);
      var first = WorkOsTaskRepository.upsertPhase1MockTask();
      var middle = WorkOsTaskRepository.createContext(sheet);
      var second = WorkOsTaskRepository.upsertPhase1MockTask();
      var after = WorkOsTaskRepository.createContext(sheet);
      assertTrue(
        countLogicalTasks(middle) === countLogicalTasks(before) ||
          countLogicalTasks(middle) === countLogicalTasks(before) + 1,
        'first upsert changed logical row count unexpectedly'
      );
      assertEqual(countLogicalTasks(middle), countLogicalTasks(after), 'second upsert duplicated Task');
      assertEqual(first.row, second.row, 'same origin_key resolved to different rows');
      assertEqual('NOOP', second.operation, 'same classification must be no-op');
    }));

    tests.push(runTest('P1-A08_LOGICAL_EMPTY_ROW', function () {
      assertEqual(
        4,
        WorkOsTaskRepository.findLogicalEmptyRow(
          [['tsk_a'], [''], ['tsk_c']],
          [['org_a'], [''], ['org_c']],
          3
        ),
        'logical empty row differs'
      );
      assertEqual(
        5,
        WorkOsTaskRepository.findLogicalEmptyRow(
          [['tsk_a'], [''], ['']],
          [['org_a'], ['org_b'], ['']],
          3
        ),
        'origin_key-only row must remain occupied'
      );
    }));

    tests.push(runTest('P1-A09_ROW_EXPANSION_UNIT', function () {
      var fakeSheet = {
        rows: 100,
        inserted: 0,
        getMaxRows: function () { return this.rows; },
        insertRowsAfter: function (after, count) {
          assertEqual(this.rows, after, 'rows must append after current capacity');
          this.rows += count;
          this.inserted += count;
        }
      };
      WorkOsTaskRepository.ensureCapacityForRow(fakeSheet, 101);
      assertEqual(100, fakeSheet.inserted, 'capacity must expand by 100 rows');
      assertEqual(200, fakeSheet.rows, 'expanded capacity differs');
    }));

    tests.push(runTest('P1-A10_SETUP_RERUN_PRESERVES_TASK', function () {
      var sheet = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.TASKS);
      WorkOsTaskRepository.upsertPhase1MockTask();
      var before = WorkOsTaskRepository.createContext(sheet);
      var taskBefore = WorkOsTaskRepository.findByOriginKey(
        before,
        phase1MockOriginKey()
      );
      var setupResult = WorkOsSetup.executeSetup();
      assertTrue(
        setupResult.status === 'PHASE_BOUNDARY' || setupResult.status === 'PAUSED',
        'Phase 1 setup must stop safely before a future stage'
      );
      var after = WorkOsTaskRepository.createContext(sheet);
      var taskAfter = WorkOsTaskRepository.findByOriginKey(
        after,
        phase1MockOriginKey()
      );
      assertEqual(taskBefore.task_id, taskAfter.task_id, 'setup rerun removed or replaced Task');
    }));

    tests.push(runTest('P1-A11_SETUP_NO_DUPLICATES', function () {
      var names = spreadsheet.getSheets().map(function (sheet) { return sheet.getName(); });
      assertEqual(names.length, Object.keys(names.reduce(function (set, name) {
        set[name] = true;
        return set;
      }, {})).length, 'duplicate Sheet names');
      var taskSchema = WorkOsSchemas.getInternalIds(WorkOsConfig.SHEETS.TASKS);
      assertEqual(
        taskSchema.length,
        Object.keys(WorkOsSchemas.buildColumnMapFromIds(taskSchema)).length,
        'duplicate Task columns'
      );
    }));

    tests.push(runTest('P1-A12_UNKNOWN_ENVIRONMENT_STOPS', function () {
      var result = WorkOsSetup.classifyEnvironmentDescriptors([
        { name: '既存業務データ', isEmpty: false, firstRow: ['重要'], secondRow: ['値'] }
      ]);
      assertEqual(false, result.allowed, 'unknown non-empty environment must stop');
      assertEqual('E_SETUP_NOT_EMPTY', result.code, 'unexpected safety code');
    }));

    tests.push(runTest('P1-A13_V1_ENVIRONMENT_STOPS', function () {
      var result = WorkOsSetup.classifyEnvironmentDescriptors([
        { name: 'Review Queue', isEmpty: false, firstRow: ['v1.3'], secondRow: [] }
      ]);
      assertEqual(false, result.allowed, 'v1 environment must stop');
      assertEqual('E_V1_DETECTED', result.code, 'unexpected v1 safety code');
    }));

    tests.push(runTest('P1-A14_DIAGNOSTIC_READ_ONLY', function () {
      var before = sheetFingerprint(spreadsheet);
      WorkOsDiagnostics.runQuickDiagnostic(spreadsheet);
      var after = sheetFingerprint(spreadsheet);
      assertEqual(before, after, 'Quick Diagnostic changed Sheet state');
    }));

    tests.push(runTest('P1-A15_REDACTION', function () {
      var unsafe = 'Authorization: Bearer abc.def token=secret-value API_KEY=top-secret';
      var safe = WorkOsUtilities.redact(unsafe);
      assertTrue(safe.indexOf('abc.def') === -1, 'Bearer credential leaked');
      assertTrue(safe.indexOf('secret-value') === -1, 'token leaked');
      assertTrue(safe.indexOf('top-secret') === -1, 'API key leaked');
    }));

    return tests;
  }

  function runPhase1AcceptanceTests() {
    var startedAt = new Date();
    var tests = phase1Tests();
    var finishedAt = new Date();
    return {
      run_id: 'TEST-' + Utilities.getUuid(),
      phase: 1,
      started_at: startedAt.toISOString(),
      finished_at: finishedAt.toISOString(),
      passed: tests.filter(function (item) { return item.status === 'PASS'; }).length,
      failed: tests.filter(function (item) { return item.status === 'FAIL'; }).length,
      skipped: tests.filter(function (item) { return item.status === 'SKIPPED'; }).length,
      tests: tests
    };
  }

  return Object.freeze({
    runPhase1AcceptanceTests: runPhase1AcceptanceTests
  });
}());

function runPhase1AcceptanceTests() {
  return WorkOsTestHarness.runPhase1AcceptanceTests();
}

function runAllTests() {
  return WorkOsTestHarness.runPhase1AcceptanceTests();
}
