function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('業務OS v2')
    .addItem('初期セットアップ', 'menuSetupSystem')
    .addItem('セットアップを続行', 'menuContinueSetup')
    .addSeparator()
    .addItem('Quick Diagnostic', 'menuQuickDiagnostic')
    .addItem('Phase 1 Mock Taskをupsert', 'menuUpsertPhase1MockTask')
    .addItem('Phase 1テストを実行', 'menuRunPhase1Tests')
    .addToUi();
}

function menuSetupSystem() {
  var ui = SpreadsheetApp.getUi();
  var response = ui.alert(
    'Phase 1 初期セットアップ',
    '新しい空のSpreadsheetまたは再開可能なv2環境だけが対象です。既存データのMigrationは行いません。続行しますか。',
    ui.ButtonSet.OK_CANCEL
  );
  if (response !== ui.Button.OK) {
    return;
  }
  showSafeResult_('初期セットアップ', setupSystem());
}

function menuContinueSetup() {
  showSafeResult_('セットアップを続行', continueSetup());
}

function menuQuickDiagnostic() {
  showSafeResult_('Quick Diagnostic', runQuickDiagnostic());
}

function menuUpsertPhase1MockTask() {
  showSafeResult_('Phase 1 Mock Task', WorkOsTaskRepository.upsertPhase1MockTask());
}

function menuRunPhase1Tests() {
  showSafeResult_('Phase 1テスト', runPhase1AcceptanceTests());
}

function showSafeResult_(title, result) {
  var safeText = WorkOsUtilities.redact(JSON.stringify(result, null, 2));
  SpreadsheetApp.getUi().alert(title, safeText.slice(0, 12000), SpreadsheetApp.getUi().ButtonSet.OK);
}

