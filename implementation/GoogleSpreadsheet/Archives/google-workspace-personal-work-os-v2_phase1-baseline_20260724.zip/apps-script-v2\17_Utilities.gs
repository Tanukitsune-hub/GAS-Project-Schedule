/**
 * Error whose user-facing fields are safe to persist or display.
 *
 * @param {string} code
 * @param {string} stage
 * @param {boolean} retryable
 * @param {string} safeMessage
 * @param {Error=} cause
 * @constructor
 */
function WorkOsAppError(code, stage, retryable, safeMessage, cause) {
  this.name = 'WorkOsAppError';
  this.code = code;
  this.stage = stage;
  this.retryable = Boolean(retryable);
  this.safeMessage = String(safeMessage || '');
  this.message = this.safeMessage;
  this.cause = cause || null;
  if (Error.captureStackTrace) {
    Error.captureStackTrace(this, WorkOsAppError);
  }
}
WorkOsAppError.prototype = Object.create(Error.prototype);
WorkOsAppError.prototype.constructor = WorkOsAppError;

var WorkOsUtilities = (function () {
  function now() {
    return new Date();
  }

  function makeId(prefix) {
    var raw = Utilities.getUuid().replace(/-/g, '');
    return String(prefix || '') + raw;
  }

  function sha256Hex(value) {
    var bytes = Utilities.computeDigest(
      Utilities.DigestAlgorithm.SHA_256,
      String(value),
      Utilities.Charset.UTF_8
    );
    return bytes.map(function (item) {
      var normalized = item < 0 ? item + 256 : item;
      return ('0' + normalized.toString(16)).slice(-2);
    }).join('');
  }

  function makeOriginKey(sourceMessageId, sourceActionIndex) {
    if (!String(sourceMessageId || '').trim()) {
      throw new WorkOsAppError(
        'E_INVALID_ORIGIN_INPUT',
        'TASK_REPOSITORY',
        false,
        'origin_keyの生成に必要な入力がありません。'
      );
    }
    var index = Number(sourceActionIndex);
    if (!Number.isInteger(index) || index < 0) {
      throw new WorkOsAppError(
        'E_INVALID_ORIGIN_INPUT',
        'TASK_REPOSITORY',
        false,
        'source_action_indexが不正です。'
      );
    }
    return 'org_' + sha256Hex('v2|' + sourceMessageId + '|' + index).slice(0, 32);
  }

  function redact(value) {
    var text = String(value == null ? '' : value);
    return text
      .replace(/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----/gi, '[REDACTED_PRIVATE_KEY]')
      .replace(/\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/gi, '$1 [REDACTED]')
      .replace(/([?&](?:token|access_token|api_key|apikey|key)=)[^&#\s]+/gi, '$1[REDACTED]')
      .replace(/\b((?:api[_-]?key|token|password|secret)\s*[:=]\s*)[^\s,;]+/gi, '$1[REDACTED]');
  }

  function safeError(error, fallbackStage) {
    if (error instanceof WorkOsAppError) {
      return {
        code: error.code,
        stage: error.stage,
        retryable: error.retryable,
        safe_message: redact(error.safeMessage)
      };
    }
    return {
      code: 'E_UNEXPECTED',
      stage: fallbackStage || 'UNKNOWN',
      retryable: false,
      safe_message: '予期しないエラーが発生しました。詳細な入力内容は記録していません。'
    };
  }

  function createSoftBudget(limitMs, startedAtMs) {
    var started = startedAtMs == null ? Date.now() : Number(startedAtMs);
    var limit = Number(limitMs);
    return Object.freeze({
      elapsedMs: function () { return Date.now() - started; },
      remainingMs: function () { return Math.max(0, limit - (Date.now() - started)); },
      isExhausted: function (reserveMs) {
        return Date.now() - started >= limit - Number(reserveMs || 0);
      }
    });
  }

  function isBlank(value) {
    return value == null || String(value).trim() === '';
  }

  function serializeJson(value, expectedKind) {
    if (value == null || value === '') {
      return expectedKind === 'array' ? '[]' : '{}';
    }
    if (typeof value === 'string') {
      var parsed = JSON.parse(value);
      if (expectedKind === 'array' && !Array.isArray(parsed)) {
        throw new Error('E_INVALID_JSON_ARRAY');
      }
      if (expectedKind === 'object' && (Array.isArray(parsed) || parsed === null || typeof parsed !== 'object')) {
        throw new Error('E_INVALID_JSON_OBJECT');
      }
      return JSON.stringify(parsed);
    }
    if (expectedKind === 'array' && !Array.isArray(value)) {
      throw new Error('E_INVALID_JSON_ARRAY');
    }
    if (expectedKind === 'object' && (Array.isArray(value) || typeof value !== 'object')) {
      throw new Error('E_INVALID_JSON_OBJECT');
    }
    return JSON.stringify(value);
  }

  function parseJson(value, expectedKind) {
    var parsed = JSON.parse(String(value));
    if (expectedKind === 'array' && !Array.isArray(parsed)) {
      throw new Error('E_INVALID_JSON_ARRAY');
    }
    if (expectedKind === 'object' && (Array.isArray(parsed) || parsed === null || typeof parsed !== 'object')) {
      throw new Error('E_INVALID_JSON_OBJECT');
    }
    return parsed;
  }

  return Object.freeze({
    now: now,
    makeId: makeId,
    sha256Hex: sha256Hex,
    makeOriginKey: makeOriginKey,
    redact: redact,
    safeError: safeError,
    createSoftBudget: createSoftBudget,
    isBlank: isBlank,
    serializeJson: serializeJson,
    parseJson: parseJson
  });
}());

