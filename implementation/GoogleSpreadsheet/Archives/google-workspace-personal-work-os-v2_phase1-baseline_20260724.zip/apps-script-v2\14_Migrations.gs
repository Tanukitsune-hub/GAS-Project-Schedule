/**
 * Phase 1 migration boundary.
 *
 * v1 -> v2 migration is deliberately unsupported. This module only exposes
 * independent version metadata and safe detection helpers for future v2 work.
 */
var WorkOsMigrations = (function () {
  function getVersionState() {
    return {
      code_version: WorkOsConfig.CODE_VERSION,
      schema_version: WorkOsConfig.SCHEMA_VERSION,
      migration_version: WorkOsConfig.MIGRATION_VERSION
    };
  }

  function isKnownV1SheetName(sheetName) {
    return WorkOsConfig.V1_SHEET_NAMES.indexOf(String(sheetName || '')) !== -1;
  }

  function assertNoV1Migration() {
    throw new WorkOsAppError(
      'E_V1_MIGRATION_UNSUPPORTED',
      'MIGRATION',
      false,
      'v1環境は自動変換できません。新しい空のSpreadsheetを使用してください。'
    );
  }

  return Object.freeze({
    getVersionState: getVersionState,
    isKnownV1SheetName: isKnownV1SheetName,
    assertNoV1Migration: assertNoV1Migration
  });
}());

function upgradeSystem() {
  return WorkOsMigrations.assertNoV1Migration();
}

