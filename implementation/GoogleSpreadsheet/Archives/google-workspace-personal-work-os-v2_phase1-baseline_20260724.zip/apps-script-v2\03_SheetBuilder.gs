/**
 * Setup-only Sheet construction. Runtime modules must not call this object.
 */
var WorkOsSheetBuilder = (function () {
  var PROTECTION_PREFIX = 'WORK_OS_V2_PHASE1_';

  function initialRowsForSheet(sheetName) {
    if (sheetName === WorkOsConfig.SHEETS.SETTINGS) {
      return WorkOsConfig.SETTINGS_INITIAL_ROWS;
    }
    if (sheetName === WorkOsConfig.SHEETS.TASKS) {
      return WorkOsConfig.TASK_INITIAL_ROWS;
    }
    return WorkOsConfig.DEFAULT_INITIAL_ROWS;
  }

  function isSheetLogicallyEmpty(sheet) {
    var values = sheet.getDataRange().getDisplayValues();
    for (var row = 0; row < values.length; row += 1) {
      for (var columnIndex = 0; columnIndex < values[row].length; columnIndex += 1) {
        if (String(values[row][columnIndex] || '').trim()) {
          return false;
        }
      }
    }
    return true;
  }

  function resizeNewBlankSheet(sheet, sheetName) {
    var targetRows = initialRowsForSheet(sheetName);
    var targetColumns = WorkOsSchemas.getSheetSchema(sheetName).length;
    var currentRows = sheet.getMaxRows();
    var currentColumns = sheet.getMaxColumns();
    if (currentRows < targetRows) {
      sheet.insertRowsAfter(currentRows, targetRows - currentRows);
    } else if (currentRows > targetRows) {
      sheet.deleteRows(targetRows + 1, currentRows - targetRows);
    }
    if (currentColumns < targetColumns) {
      sheet.insertColumnsAfter(currentColumns, targetColumns - currentColumns);
    } else if (currentColumns > targetColumns) {
      sheet.deleteColumns(targetColumns + 1, currentColumns - targetColumns);
    }
  }

  function ensureMinimumGrid(sheet, sheetName) {
    var minimumRows = initialRowsForSheet(sheetName);
    var minimumColumns = WorkOsSchemas.getSheetSchema(sheetName).length;
    if (sheet.getMaxRows() < minimumRows) {
      sheet.insertRowsAfter(sheet.getMaxRows(), minimumRows - sheet.getMaxRows());
    }
    if (sheet.getMaxColumns() < minimumColumns) {
      sheet.insertColumnsAfter(
        sheet.getMaxColumns(),
        minimumColumns - sheet.getMaxColumns()
      );
    }
  }

  function ensureSheets(spreadsheet) {
    var created = [];
    var existingSheets = spreadsheet.getSheets();
    var firstSheet = existingSheets.length === 1 ? existingSheets[0] : null;
    var canRenameFirst = firstSheet &&
      WorkOsSheetOrder.indexOf(firstSheet.getName()) === -1 &&
      isSheetLogicallyEmpty(firstSheet);

    WorkOsSheetOrder.forEach(function (sheetName, index) {
      var sheet = spreadsheet.getSheetByName(sheetName);
      if (!sheet) {
        if (index === 0 && canRenameFirst) {
          firstSheet.setName(sheetName);
          sheet = firstSheet;
          canRenameFirst = false;
        } else {
          sheet = spreadsheet.insertSheet(sheetName, index);
        }
        resizeNewBlankSheet(sheet, sheetName);
        created.push(sheetName);
      } else {
        // Resume safely if a prior S10 execution stopped after creating only
        // part of a Sheet grid. Existing grids are never shrunk.
        ensureMinimumGrid(sheet, sheetName);
      }
      var currentIndex = spreadsheet.getSheets().indexOf(sheet);
      if (currentIndex !== index) {
        var wasHidden = sheet.isSheetHidden();
        if (wasHidden) {
          sheet.showSheet();
        }
        spreadsheet.setActiveSheet(sheet);
        spreadsheet.moveActiveSheet(index + 1);
        if (wasHidden) {
          sheet.hideSheet();
        }
      }
    });

    return {
      created: created,
      sheets: WorkOsSheetOrder.reduce(function (result, name) {
        result[name] = spreadsheet.getSheetByName(name);
        return result;
      }, {})
    };
  }

  function allBlank(values) {
    return values.every(function (value) {
      return WorkOsUtilities.isBlank(value);
    });
  }

  function applySchemaToSheet(sheet, sheetName) {
    var schema = WorkOsSchemas.getSheetSchema(sheetName);
    var ids = schema.map(function (item) { return item.id; });
    var headers = schema.map(function (item) { return item.header; });
    var existingIds = sheet.getRange(
      WorkOsConfig.HEADER_ID_ROW,
      1,
      1,
      schema.length
    ).getValues()[0];
    var existingHeaders = sheet.getRange(
      WorkOsConfig.HEADER_LABEL_ROW,
      1,
      1,
      schema.length
    ).getValues()[0];
    var comparison = WorkOsSchemas.compareHeaders(sheetName, existingIds, existingHeaders);

    if (allBlank(existingIds) && allBlank(existingHeaders)) {
      sheet.getRange(WorkOsConfig.HEADER_ID_ROW, 1, 1, schema.length).setValues([ids]);
      sheet.getRange(WorkOsConfig.HEADER_LABEL_ROW, 1, 1, schema.length).setValues([headers]);
    } else if (comparison.idsMatch && comparison.headersMatch) {
      // Exact v2 schema: rerun is a no-op for cell values.
    } else if (comparison.idsMatch && existingHeaders.every(function (value, index) {
      return WorkOsUtilities.isBlank(value) || String(value) === headers[index];
    })) {
      // Safe recovery from interruption between row 1 and row 2.
      sheet.getRange(WorkOsConfig.HEADER_LABEL_ROW, 1, 1, schema.length).setValues([headers]);
    } else {
      throw new WorkOsAppError(
        'E_SCHEMA_CONFLICT',
        'S20_CREATE_SCHEMAS',
        false,
        sheetName + 'の既存Schemaがv2仕様と一致しないため停止しました。'
      );
    }

    sheet.setFrozenRows(2);
    sheet.hideRows(WorkOsConfig.HEADER_ID_ROW);
    sheet.getRange(WorkOsConfig.HEADER_ID_ROW, 1, 1, schema.length)
      .setFontWeight('bold')
      .setBackground('#e8eaed');
    sheet.getRange(WorkOsConfig.HEADER_LABEL_ROW, 1, 1, schema.length)
      .setFontWeight('bold')
      .setBackground('#d9eaf7');

    if (sheetName === WorkOsConfig.SHEETS.TASKS) {
      var firstHidden = schema.findIndex(function (item) { return item.visible === false; });
      if (firstHidden >= 0) {
        sheet.hideColumns(firstHidden + 1, schema.length - firstHidden);
      }
    }
    ensureSmallProtections(sheet, sheetName, schema);

    return WorkOsSchemas.buildColumnMapFromIds(ids);
  }

  function ensureSmallProtections(sheet, sheetName, schema) {
    if (typeof sheet.getProtections !== 'function') {
      return;
    }
    var existingDescriptions = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE)
      .map(function (protection) { return protection.getDescription(); });
    var headerDescription = PROTECTION_PREFIX + sheetName + '_HEADER_IDS';
    if (existingDescriptions.indexOf(headerDescription) === -1) {
      sheet.getRange(1, 1, 1, schema.length)
        .protect()
        .setDescription(headerDescription)
        .setWarningOnly(true);
    }
    if (sheetName === WorkOsConfig.SHEETS.TASKS) {
      var firstHidden = schema.findIndex(function (item) { return item.visible === false; });
      var managementDescription = PROTECTION_PREFIX + sheetName + '_MANAGEMENT_COLUMNS';
      if (firstHidden >= 0 && existingDescriptions.indexOf(managementDescription) === -1) {
        sheet.getRange(
          1,
          firstHidden + 1,
          sheet.getMaxRows(),
          schema.length - firstHidden
        ).protect()
          .setDescription(managementDescription)
          .setWarningOnly(true);
      }
    }
  }

  function applyAllSchemas(spreadsheet) {
    var columnMaps = {};
    WorkOsSheetOrder.forEach(function (sheetName) {
      var sheet = spreadsheet.getSheetByName(sheetName);
      if (!sheet) {
        throw new WorkOsAppError(
          'E_SCHEMA_MISSING_SHEET',
          'S20_CREATE_SCHEMAS',
          false,
          '必須Sheetがありません: ' + sheetName
        );
      }
      columnMaps[sheetName] = applySchemaToSheet(sheet, sheetName);
    });
    SpreadsheetApp.flush();
    return columnMaps;
  }

  function buildValidationRule(planItem) {
    if (planItem.validation === 'CHECKBOX') {
      return SpreadsheetApp.newDataValidation()
        .requireCheckbox()
        .setAllowInvalid(false)
        .build();
    }
    if (planItem.validation === 'ENUM' && planItem.allowedValues) {
      return SpreadsheetApp.newDataValidation()
        .requireValueInList(planItem.allowedValues, true)
        .setAllowInvalid(false)
        .build();
    }
    return null;
  }

  function applyValidationsAndFormats(spreadsheet) {
    WorkOsSheetOrder.forEach(function (sheetName) {
      var sheet = spreadsheet.getSheetByName(sheetName);
      var schema = WorkOsSchemas.getSheetSchema(sheetName);
      var dataRowCount = Math.max(0, sheet.getMaxRows() - WorkOsConfig.DATA_START_ROW + 1);
      if (!dataRowCount) {
        return;
      }
      WorkOsSchemas.validationPlanForSheet(sheetName).forEach(function (planItem) {
        var rule = buildValidationRule(planItem);
        if (rule) {
          sheet.getRange(
            WorkOsConfig.DATA_START_ROW,
            planItem.columnIndex,
            dataRowCount,
            1
          ).setDataValidation(rule);
        }
      });
      schema.forEach(function (item, index) {
        var range = sheet.getRange(
          WorkOsConfig.DATA_START_ROW,
          index + 1,
          dataRowCount,
          1
        );
        if (item.type === 'Date') {
          range.setNumberFormat(WorkOsConfig.DATE_FORMAT);
        } else if (item.type === 'DateTime') {
          range.setNumberFormat(WorkOsConfig.DATETIME_FORMAT);
        } else if (item.type === 'Integer') {
          range.setNumberFormat('0');
        } else if (item.type === 'Number') {
          range.setNumberFormat('0.00');
        }
      });
    });
  }

  function findFirstEmptyKeyRow(sheet, keyColumnIndex) {
    var rowCount = sheet.getMaxRows() - WorkOsConfig.DATA_START_ROW + 1;
    var values = sheet.getRange(
      WorkOsConfig.DATA_START_ROW,
      keyColumnIndex,
      rowCount,
      1
    ).getValues();
    for (var index = 0; index < values.length; index += 1) {
      if (WorkOsUtilities.isBlank(values[index][0])) {
        return WorkOsConfig.DATA_START_ROW + index;
      }
    }
    sheet.insertRowsAfter(sheet.getMaxRows(), WorkOsConfig.ROW_EXPANSION_UNIT);
    return sheet.getMaxRows() - WorkOsConfig.ROW_EXPANSION_UNIT + 1;
  }

  function seedRowsByKey(sheet, sheetName, keyId, rows) {
    var schema = WorkOsSchemas.getSheetSchema(sheetName);
    var ids = schema.map(function (item) { return item.id; });
    var map = WorkOsSchemas.buildColumnMapFromIds(ids);
    var keyColumn = map[keyId] + 1;
    var rowCount = sheet.getMaxRows() - WorkOsConfig.DATA_START_ROW + 1;
    var existingKeys = sheet.getRange(
      WorkOsConfig.DATA_START_ROW,
      keyColumn,
      rowCount,
      1
    ).getValues().map(function (row) { return String(row[0] || ''); });

    rows.forEach(function (record) {
      if (existingKeys.indexOf(String(record[keyId])) !== -1) {
        return;
      }
      var targetRow = findFirstEmptyKeyRow(sheet, keyColumn);
      var output = ids.map(function (id) {
        return Object.prototype.hasOwnProperty.call(record, id) ? record[id] : '';
      });
      sheet.getRange(targetRow, 1, 1, output.length).setValues([output]);
      existingKeys[targetRow - WorkOsConfig.DATA_START_ROW] = String(record[keyId]);
    });
  }

  function safeSettingsSeed(nowValue) {
    return [
      ['timezone', 'タイムゾーン', WorkOsConfig.TIMEZONE, 'STRING', WorkOsConfig.TIMEZONE, '日付計算基準', false],
      ['automation_enabled', '自動処理', false, 'BOOLEAN', 'false', 'Phase 1では停止', false],
      ['ai_provider', 'AI Provider', WorkOsConfig.AI_PROVIDER, 'STRING', 'MOCK', 'Phase 1は外部通信なし', false],
      ['manual_max_messages', '手動最大メッセージ数', 1, 'INTEGER', '1', '将来Phase用の安全な既定値', true],
      ['auto_max_messages', '自動最大メッセージ数', 10, 'INTEGER', '1..10', '将来Phase用の安全な既定値', true],
      ['manual_soft_limit_sec', '手動soft limit秒', 120, 'INTEGER', '30..120', '将来Phase用', true],
      ['auto_soft_limit_sec', '自動soft limit秒', 210, 'INTEGER', '60..210', '将来Phase用', true],
      ['lock_wait_ms', 'Lock待機ms', 5000, 'INTEGER', '5000', '将来Phase用', true],
      ['max_actions_per_message', '最大Action数', 10, 'INTEGER', '1..10', '将来Phase用', true],
      ['deadline_calendar_name', '専用Calendar名', WorkOsConfig.DEADLINE_CALENDAR_NAME, 'STRING', WorkOsConfig.DEADLINE_CALENDAR_NAME, 'Phase 1では作成しない', false]
    ].map(function (item) {
      return {
        setting_key: item[0],
        display_name: item[1],
        value: item[2],
        value_type: item[3],
        allowed_values: item[4],
        description: item[5],
        editable: item[6],
        updated_at: nowValue
      };
    });
  }

  function seedSafeSettings(spreadsheet) {
    var nowValue = WorkOsUtilities.now();
    seedRowsByKey(
      spreadsheet.getSheetByName(WorkOsConfig.SHEETS.SETTINGS),
      WorkOsConfig.SHEETS.SETTINGS,
      'setting_key',
      safeSettingsSeed(nowValue)
    );
    seedRowsByKey(
      spreadsheet.getSheetByName(WorkOsConfig.SHEETS.SYSTEM_CONFIG),
      WorkOsConfig.SHEETS.SYSTEM_CONFIG,
      'config_key',
      [
        { config_key: 'code_version', config_value: WorkOsConfig.CODE_VERSION, value_type: 'STRING', updated_at: nowValue, note: 'Phase 1' },
        { config_key: 'schema_version', config_value: WorkOsConfig.SCHEMA_VERSION, value_type: 'STRING', updated_at: nowValue, note: 'Phase 1' },
        { config_key: 'migration_version', config_value: WorkOsConfig.MIGRATION_VERSION, value_type: 'STRING', updated_at: nowValue, note: 'v1 migration unsupported' },
        { config_key: 'automation_enabled', config_value: 'false', value_type: 'BOOLEAN', updated_at: nowValue, note: 'Initial state' }
      ]
    );
    seedRowsByKey(
      spreadsheet.getSheetByName(WorkOsConfig.SHEETS.GUIDE),
      WorkOsConfig.SHEETS.GUIDE,
      'step_id',
      [
        { step_id: '1', title: '初期セットアップ', instruction: 'メニューから初期セットアップを実行します。Phase 1ではS50で安全停止します。' },
        { step_id: '2', title: 'Quick Diagnostic', instruction: '構成を読取専用で確認します。' },
        { step_id: '3', title: 'Mock Task', instruction: '完全なダミーデータだけを登録します。' }
      ]
    );
  }

  function applyVisibility(spreadsheet) {
    WorkOsHiddenSheets.forEach(function (sheetName) {
      var sheet = spreadsheet.getSheetByName(sheetName);
      if (sheet && !sheet.isSheetHidden()) {
        sheet.hideSheet();
      }
    });
    var dashboard = spreadsheet.getSheetByName(WorkOsConfig.SHEETS.DASHBOARD);
    if (dashboard && dashboard.isSheetHidden()) {
      dashboard.showSheet();
    }
    spreadsheet.setActiveSheet(dashboard);
  }

  return Object.freeze({
    isSheetLogicallyEmpty: isSheetLogicallyEmpty,
    ensureSheets: ensureSheets,
    applyAllSchemas: applyAllSchemas,
    applyValidationsAndFormats: applyValidationsAndFormats,
    seedSafeSettings: seedSafeSettings,
    applyVisibility: applyVisibility,
    initialRowsForSheet: initialRowsForSheet
  });
}());
